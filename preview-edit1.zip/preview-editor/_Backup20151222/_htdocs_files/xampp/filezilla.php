<?php
	include "langsettings.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler, Kay Vogelgesang, Carsten Wiedmann">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title></title>
	</head>

	<body>
		&nbsp;<p>
		<h1><?php echo $TEXT['filezilla-head']; ?></h1>

		<table width="600" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td align="left" width="600"><?php echo $TEXT['filezilla-install']; ?></td>
			</tr>


			<tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>

			<tr>
				<td align="left" width="600"><?php echo $TEXT['filezilla-install2']; ?></td>
			</tr>

      <tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>

			<tr>
				<td align="left" width="600"><img src="img/cp-filezilla-login.gif" alt="Connect to FileZilla Server"></td>
			</tr>		
			
			<tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>

			<tr>
				<td align="left" width="600"><img src="img/filezilla-panel.gif" alt="Filezilla Management Interface"></td>
			</tr>

			<tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>

			<tr>
				<td align="left" width="600"><?php echo $TEXT['filezilla-install4'];?></td>
			</tr>

			<tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>

			<tr>
				<td align="left" width="600"><?php echo $TEXT['filezilla-url']; ?></td>
			</tr>

			<tr>
				<td align="left" width="600">&nbsp;</td>
			</tr>
		</table>
	</body>
</html>
