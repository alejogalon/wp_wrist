<!DOCTYPE html>
<html>
<body>

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <rect x="0" y="0" height="70" width="300" style="fill: red"/>
  <!--<image x="0" y="-65" height="200" width="300" xlink:href="band.png" />-->
  <image x="0" y="-62" height="200" width="300" xlink:href="band2.png" />
</svg>

<!--<svg width="96" height="96">
  <image xlink:href="svg.svg" src="band.png" width="96" height="96" />
</svg>-->
</body>
</html>