<!DOCTYPE html>
<html>
<body>

<p>Click the button to display an alert box:</p>

<button onclick="myFunction()">Try it</button>

<script>
// 0 to 255
function cfunction(a,b){
   var t = a + b;
    if(t > 255){
        t = t % 255;
        return(t);
    }else{
        return(t);
    }
}
cfunction(200,56);
</script>

</body>
</html>
