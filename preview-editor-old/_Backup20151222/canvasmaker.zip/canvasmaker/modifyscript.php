<?php
$file_handle = fopen("js/tmp.js", "r");
while (!feof($file_handle)) {
    $line = fgets($file_handle);
    if(strpos($line, 'imgToCanvas') !== false){
        echo 'function imgToCanvas(r = 0,g = 0,b = 0,a = 0){'.'<br>';
    }else if (strpos($line, 'rgba') !== false) {
        $tmp = explode(',', $line);
        $firstVal = substr($tmp[0], strpos($tmp[0], "(") + 1);
        $secondVal = $tmp[1];
        $thirdVal = $tmp[2];
        $fourthVal = current(explode(")", $tmp[3]));
        $thisColor = 'cx.fillStyle="rgba("+('.$firstVal.' + r)+","+('.$secondVal.' + g)+","+('.$thirdVal.' + b)+","+('.$fourthVal.' + a)+")";';
//        $thisColor = 'cx.fillStyle="rgba("+ cfunction('.$firstVal.', r) +","+ cfunction('.$secondVal.' , g) +","+ cfunction('.$thirdVal.' , b) +","+ cfunction('.$fourthVal.' , a) +")";';

        echo $thisColor . '<br>';
    } else {
        echo $line . '<br>';
    }
}
?>