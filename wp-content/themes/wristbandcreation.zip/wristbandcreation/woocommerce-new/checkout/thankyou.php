<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="woocommerce-order">

	<?php if ( $order ) : ?>

		<?php if ( $order->has_status( 'failed' ) ) : ?>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php _e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?></p>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
				<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php _e( 'Pay', 'woocommerce' ) ?></a>
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php _e( 'My account', 'woocommerce' ); ?></a>
				<?php endif; ?>
			</p>

		<?php else : ?>

			<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Thank you. Your order has been received.', 'woocommerce' ), $order ); ?></p>

			<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">

				<li class="woocommerce-order-overview__order order">
					<?php _e( 'Order number:', 'woocommerce' ); ?>
					<strong><?php echo $order->get_order_number(); ?></strong>
				</li>

				<li class="woocommerce-order-overview__date date">
					<?php _e( 'Date:', 'woocommerce' ); ?>
					<strong><?php echo wc_format_datetime( $order->get_date_created() ); ?></strong>
				</li>

				<li class="woocommerce-order-overview__total total">
					<?php _e( 'Total:', 'woocommerce' ); ?>
					<strong><?php echo $order->get_formatted_order_total(); ?></strong>
				</li>

				<?php if ( $order->get_payment_method_title() ) : ?>

				<li class="woocommerce-order-overview__payment-method method">
					<?php _e( 'Payment method:', 'woocommerce' ); ?>
					<strong><?php echo wp_kses_post( $order->get_payment_method_title() ); ?></strong>
				</li>

				<?php endif; ?>

			</ul>

		<?php endif; ?>

		<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() ); ?>
		<?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>

	<?php else : ?>

		<!-- <p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Thank you. Your order has been received.', 'woocommerce' ), null ); ?></p> -->

		<div class="row row-thanks">
			<div class="col-md-4">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/wristband/assets/images/thankyou_img.png" width="333" height="466" alt="">
			</div>
			<div class="col-md-8">
				<?php if ($order->payment_method == 'cheque') { ?>
				<h2><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Your order is on-hold.', 'woocommerce' ), $order ); ?></h2>
				<span class="copy-font-big copy-block" style="line-height: 24px;">Please check your email address with the details on how to complete your order. Production of wristbands will only begin once we receive the check or Purchase Order.</span>	
				<?php } else { ?>
				<h2><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Your order has been received!', 'woocommerce' ), $order ); ?></h2>
				<span class="copy-font-big">We’ve sent you an email with all the details of your order.</span>
				<?php } ?>
				<ul class="order_details">
					<li class="order">
						<p class="copy-upper copy-gray copy-proxima-bold copy-detail-title copy-spacing"><?php _e( 'Order Number', 'woocommerce' ); ?></p>
						<strong class="copy-block copy-font-big">878</strong>
					</li>
					<li class="date">
						<p class="copy-upper copy-gray copy-proxima-bold copy-detail-title copy-spacing"><?php _e( 'Date', 'woocommerce' ); ?></p>
						<strong class="copy-block copy-font-big">
							<?php echo date_i18n( 'F d, Y', strtotime( $order->order_date ) ); ?>
						</strong>
					</li>
					<li class="total">
						<p class="copy-upper copy-gray copy-proxima-bold copy-detail-title copy-spacing"><?php _e( 'Total', 'woocommerce' ); ?></p>
						<strong class="copy-block copy-font-big">
							$824.80
						</strong>
					</li>
					<li class="method">
						<p class="copy-upper copy-gray copy-proxima-bold copy-detail-title copy-spacing"><?php _e( 'Payment Method', 'woocommerce' ); ?></p>
						<strong class="copy-block copy-font-big">
							Direct Bank Transfer
						</strong>
					</li>
				</ul>

				<div class="section-share">
					<p class="copy-proxima-sbold copy-upper copy-spacing copy-float-left copy-share">Share your wristband</p>
					<a class="fa-custom" href="http://www.facebook.com/share.php?u=<?php echo get_permalink(); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" title="Share on Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
				</div>
				<div class="clear"></div>
			</div>
		</div>

	<?php endif; ?>

</div>
