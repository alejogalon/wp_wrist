<?php
/**
 * Pay for order form
 *
 * @author   WooThemes
 * @package  WooCommerce/Templates
 * @version  2.4.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


?>
<div class="container">
	<form class="order-pay" id="order_review" method="post" style="border: none !important;padding: 0;">

	<table class="shop_table" style="display: block;">
		<thead class="copy-block">
		<tr style="width: 100%;display: block;">
			<th class="product-name copy-proxima-reg" style="text-transform: uppercase; letter-spacing: 1px; font-size: 16px; color: #606060;width: 50%; float: left;padding-left: 25px;"><?php _e( 'ITEM', 'woocommerce' ); ?></th>
			<th class="product-quantity copy-proxima-reg text-center" style="text-transform: uppercase; letter-spacing: 1px; font-size: 16px; color: #606060;width: 25%; float: left;"><?php _e( 'QTY', 'woocommerce' ); ?></th>
			<th class="product-total copy-proxima-reg text-center" style="text-transform: uppercase; letter-spacing: 1px; font-size: 16px; color: #606060;width: 25%; float: left;"><?php _e( 'SUBTOTAL', 'woocommerce' ); ?></th>
		</tr>
		</thead>
		<tbody style="border: 1px solid #e0dede;font-size: 16px; font-family: 'ProximaNovaSbold'; padding: 25px 25px 0; float: left; width: 100%;">
		<?php
		if ( sizeof( $order->get_items() ) > 0 ) :
			foreach ( $order->get_items() as $item ) :
				$item_meta = new WC_Order_Item_Meta( $item['item_meta'] );
				$_product  = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
                foreach ($item_meta as $key => $value) {
                  if($key == 'meta'){
                    $meta = unserialize($value['wristband_meta'][0]);
                  }
                }
				echo '
						<tr style="height: auto; display: block;float: left; width: 100%;padding-top: 1em;">
							<td class="product-name" style="float: left;padding: 0;"><table><tr><td class="table-product-name" style="padding: 0; position: absolute; font-size: 16px; font-family:ProximaNovaSbold;">' . $item['name']. ' Wristbands' .'</td><td>';
				display_order_summary($_product, $meta);
				echo '
							</td></tr></table></td>
							<td class="product-quantity" style="width: 25%;float: left;padding: 0;">' . $item['qty'].'</td>
							<td class="product-subtotal" style="width: 25%;float: left;padding: 0;position: relative;">' . $order->get_formatted_line_subtotal( $item ) . '</td>
						</tr>';				
			endforeach;
		endif;
		?>
		</tbody>
		<tfoot class="copy-tfoot-pay copy-float-left" style="width: 100%; background: #f2f5f8; padding: 2em; margin: 1em 0;font-size: 16px;">
		<?php
		if ( $totals = $order->get_order_item_totals() ) foreach ( $totals as $total ) : if( $total['label'] == 'Shipping:') continue;
			?>
			<tr class="copy-float-left" style="border-color: #e5e6e6;padding: 10px 0;width: 100%;">
				<th class="copy-proxima-sbold copy-float-left" scope="row" colspan="2" style="line-height: 1;"><?php echo $total['label']; ?></th>
				<td class="product-total" style="padding: 0; line-height: 1;"><?php echo $total['value']; ?></td>
			</tr>
			<?php
		endforeach;
		?>
		</tfoot>
	</table>

	<div class="copy-float-left copy-form-pay-payment" id="payment" style="width: 100%;padding: 0;font-size: 16px;">
		<?php if ( $order->needs_payment() ) : ?>
			<ul class="payment_methods methods" style="margin: 1em 25px;">
				<?php
				if ( $available_gateways = WC()->payment_gateways->get_available_payment_gateways() ) {
					// Chosen Method
					if ( sizeof( $available_gateways ) ) {
						current( $available_gateways )->set_current();
					}

					foreach ( $available_gateways as $gateway ) {
						?>
						<li class="copy-block payment_method_<?php echo $gateway->id; ?>">
							<input id="payment_method_<?php echo $gateway->id; ?>" type="radio" class="input-radio" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>" />
							<label for="payment_method_<?php echo $gateway->id; ?>"><?php echo $gateway->get_title(); ?> <?php echo $gateway->get_icon(); ?></label>
							<?php
							if ( $gateway->has_fields() || $gateway->get_description() ) {
								echo '<div class="payment_box payment_method_' . $gateway->id . '" style="display:none;">';
								$gateway->payment_fields();
								echo '</div>';
							}
							?>
						</li>
						<?php
					}
				} else {

					echo '<p>' . __( 'Sorry, it seems that there are no available payment methods for your location. Please contact us if you require assistance or wish to make alternate arrangements.', 'woocommerce' ) . '</p>';

				}
				?>
			</ul>
		<?php endif; ?>

		<div class="form-row copy-form-pay-submit">
			<?php wp_nonce_field( 'woocommerce-pay' ); ?>
			<?php
			$pay_order_button_text = apply_filters( 'woocommerce_pay_order_button_text', __( 'Pay for order', 'woocommerce' ) );

			echo apply_filters( 'woocommerce_pay_order_button_html', '<input type="submit" class="button alt" id="place_order" value="' . esc_attr( $pay_order_button_text ) . '" data-value="' . esc_attr( $pay_order_button_text ) . '" />' );
			?>
			<input type="hidden" name="woocommerce_pay" value="1" />
		</div>

	</div>

</form>
</div>


