<?php 

function change_font_to_label($fontname) {

  if($fontname == 'Asset'){
    $fontname = 'hello';
  } else if ($fontname == 'hotel-open'){
    $fontname = 'Hotel Open';
  } else if ($fontname == 'salsbury'){
    $fontname = 'Salsbury';
  } else if ($fontname == 'lourdes'){
    $fontname = 'Lourdes';
  } else if ($fontname == 'museo-slab'){
    $fontname = 'Museo Slab';
  } else if ($fontname == 'great-primer-sc'){
    $fontname = 'Great Primer Sc';    
  } else if ($fontname == 'badaboom-pro'){
    $fontname = 'Bada Boom Pro';
  } else if ($fontname == 'dry-cowboy'){
    $fontname = 'Dry Cowboys';
  } else if ($fontname == 'zubilo-web-black'){
    $fontname = 'Zubilo Web Black';
  } else if ($fontname == 'stencil-std'){
    $fontname = 'Stencil Std';
  } else if ($fontname == 'hobo-std'){
    $fontname = 'Hobo Std';
  } else if ($fontname == 'sneakers-script-narrow'){
    $fontname = 'Sneakers Script Narrow';
  } else if ($fontname == 'hwt-geometric-condensed'){
    $fontname = 'HWT Geometric';
  } else if ($fontname == 'blenny'){
    $fontname = 'Blennys';
  } else if ($fontname == 'balloon-urw-drop-shadow'){
    $fontname = 'Balloon Shadow';
  } else if ($fontname == 'discourse-middle-shadow'){
    $fontname = 'Discourse Shadow';
  } else if ($fontname == 'kinescope'){
    $fontname = 'Kinescope';
  } else if ($fontname == 'le-monde-livre-classic-std-s'){
    $fontname = 'Le Monde Livre';
  } else if ($fontname == 'sanvito-pro'){
    $fontname = 'Sanvito';
  } else if ($fontname == 'lobster'){
    $fontname = 'Lobster';
  } else if ($fontname == 'jaf-herb'){
    $fontname = 'Jaf Herb';
  } else if ($fontname == 'cabazon'){
    $fontname = 'Cabazon';
  } else if ($fontname == 'ff-market-web'){
    $fontname = 'FF Market Web';
  } else if ($fontname == 'uppercut-angle'){
    $fontname = 'Uppercut Angle';
  } else if ($fontname == 'sketchnote-text'){
    $fontname = 'Sketch Note';
  } else if ($fontname == 'subway-berlin-sc'){
    $fontname = 'Subway Berlin';
  } else if ($fontname == 'lint-mccree'){
    $fontname = 'Lint';
  } else if ($fontname == 'discourse-narrow-outline'){
    $fontname = 'Discourse Narrow';
  } else if ($fontname == 'hwt-van-lanen'){
    $fontname = 'Van Lanen';
  } else if ($fontname == 'aw-conqueror-carved-two'){
    $fontname = 'Conqueror Carved';
  } else if ($fontname == 'strumpf-std-open'){
    $fontname = 'Strumpf';
  } else if ($fontname == 'bigfish'){
    $fontname = 'Bigfish';
  } else if ($fontname == 'adelle'){
    $fontname = 'Adelle';
  } else if ($fontname == 'AlbaRegular'){
    $fontname = 'Alba';
  } else if ($fontname == 'BadaBoomBBRegular'){
    $fontname = 'Badoom';
  } else if ($fontname == 'AllstarRegular'){
    $fontname = 'Allstar Regular';
  } else if ($fontname == 'AlbertTextBold'){
    $fontname = 'Albert';
  } else if ($fontname == 'Baron'){
    $fontname = 'Baron';
  } else if ($fontname == 'BeckasinRegular'){
    $fontname = 'Beckasin';
  } else if ($fontname == 'BaveuseRegular'){
    $fontname = 'Baveuse';
  } else if ($fontname == 'Bigmouth'){
    $fontname = 'Bigmouth';
  } else if ($fontname == 'BlockHeadRegular'){
    $fontname = 'Block Head';
  } else if ($fontname == 'BlockHeadFat'){
    $fontname = 'Block Head Fat';
  } else if ($fontname == 'Bob'){
    $fontname = 'Bob';
  } else if ($fontname == 'BankGothicMdBTMedium'){
    $fontname = 'Bank Gothic';
  } else if ($fontname == 'Bohema'){
    $fontname = 'Bohema';
  } else if ($fontname == 'Calendas_Plus'){
    $fontname = 'Calendas Plus';    
  } else if ($fontname == 'CenturyGothic'){
    $fontname = 'Century Gothic';
  } else if ($fontname == 'BlockHeadBold'){
    $fontname = 'Blockhead Bold';
  } else if ($fontname == 'ChunkFive'){
    $fontname = 'Chunk Five';
  } else if ($fontname == 'CodePro'){
    $fontname = 'Code Pro';
  } else if ($fontname == 'Construthinvism'){
    $fontname = 'Construth';
  } else if ($fontname == 'EastLiftRegular'){
    $fontname = 'East Lift';
  } else if ($fontname == 'CopprplGothBdBTBold'){
    $fontname = 'Cop Goth';
  } else if ($fontname == 'CourierNewRegular'){
    $fontname = 'Courier New';
  } else if ($fontname == 'Cylburn'){
    $fontname = 'Cylburn';
  } else if ($fontname == 'Dense'){
    $fontname = 'Dense';
  } else if ($fontname == 'Dooodleista'){
    $fontname = 'Dooodleista';
  } else if ($fontname == 'GammaRayMedium'){
    $fontname = 'Gamma Ray';
  } else if ($fontname == 'EurostileRegular'){
    $fontname = 'Eurosti';
  } else if ($fontname == 'FirestarterRegular'){
    $fontname = 'Fire Starter';
  } else if ($fontname == 'Flex'){
    $fontname = 'Flex';
  } else if ($fontname == 'GearedSlab'){
    $fontname = 'Geared Slab';
  } else if ($fontname == 'Geogram'){
    $fontname = 'Geogram';
  } else if ($fontname == 'GoodDog'){
    $fontname = 'Good Dog';
  } else if ($fontname == 'GrandHotel'){
    $fontname = 'Grand Hotel';
  } else if ($fontname == 'Habana'){
    $fontname = 'Habana';
  } else if ($fontname == 'Haymaker'){
    $fontname = 'Haymeker';
  } else if ($fontname == 'Higher'){
    $fontname = 'Higher';
  } else if ($fontname == 'HirukoBlackAlternate'){
    $fontname = 'Hiruko Black';
  } else if ($fontname == 'Atama__GRegular'){
    $fontname = 'Atama Geomarice';
  } else if ($fontname == 'Kilogram'){
    $fontname = 'Kilogram';
  } else if ($fontname == 'LEADvilleASTROnautInlineRg'){
    $fontname = 'Lead Ville Inline';
  } else if ($fontname == 'KeeponTruckinRegular'){
    $fontname = 'Keep on Truckin';
  } else if ($fontname == 'KlinicSlabBook'){
    $fontname = 'Klinic Slab';
  } else if ($fontname == 'Komoda'){
    $fontname = 'Komoda';
  } else if ($fontname == 'Lavanderia'){
    $fontname = 'Lavanderia';
  } else if ($fontname == 'Linny'){
    $fontname = 'Linny';
  } else if ($fontname == 'Lobster'){
    $fontname = 'Lobster';
  } else if ($fontname == 'Makhina'){
    $fontname = 'Makhina';
  } else if ($fontname == 'MasterforceRegular'){
    $fontname = 'Master Force';
  } else if ($fontname == 'Metropolis'){
    $fontname = 'Metropolis';
  } else if ($fontname == 'LEADvilleASTROnautSystemRg'){
    $fontname = 'Lead Ville System';
  } else if ($fontname == 'Molesk'){
    $fontname = 'Molesk';
  } else if ($fontname == 'Moonshiner'){
    $fontname = 'Moonshiner';
  } else if ($fontname == 'NexaLight'){
    $fontname = 'Nexa Light';
  } else if ($fontname == 'NexaBold'){
    $fontname = 'Nexa Bold';
  } else if ($fontname == 'OldeEnglishRegular'){
    $fontname = 'Old English';
  } else if ($fontname == 'NovaMonoRegular'){
    $fontname = 'Nova Mono';
  } else if ($fontname == 'NymphsHandwritingRegular'){
    $fontname = 'Nymphs Handwriting';
  } else if ($fontname == 'OstrichSans'){
    $fontname = 'Ostrich Sans';
  } else if ($fontname == 'Parisish'){
    $fontname = 'Parisish';
  } else if ($fontname == 'QuadrantaRegular'){
    $fontname = 'Quadranta';
  } else if ($fontname == 'PlanetBenson2Regular'){
    $fontname = 'Planet Benson 2';
  } else if ($fontname == 'QuadrantaBold'){
    $fontname = 'Quadranta B';
  } else if ($fontname == 'RoddenberryRegular'){
    $fontname = 'Roddenberry';
  } else if ($fontname == 'Reckoner'){
    $fontname = 'Reckoner';
  } else if ($fontname == 'RobofanFreeRegular'){
    $fontname = 'Robo Fan Free';
  } else if ($fontname == 'StonehengeRegular'){
    $fontname = 'Stonehenge';
  } else if ($fontname == 'SevenSwordsmenBBRegular'){
    $fontname = 'Seven Swordsmen';
  } else if ($fontname == 'SFSlapstickComicRegular'){
    $fontname = 'Slapstick Comic';
  } else if ($fontname == 'unlikeEdgeRegular'){
    $fontname = 'Unlike Edge';
  } else if ($fontname == 'VTCSuperMarketSaleDisplayRg'){
    $fontname = 'Supermarket Sale';
  } else if ($fontname == 'thebubblelettersRegular'){
    $fontname = 'The Bubble';
  } else if ($fontname == 'TrackType'){
    $fontname = 'Track Type';
  } else if ($fontname == 'TrueLove'){
    $fontname = 'True Love';
  } else if ($fontname == 'WoodShop'){
    $fontname = 'Wood Shop';
  } else if ($fontname == 'WoodWarrior'){
    $fontname = 'Wood Warrior';
  } else if ($fontname == 'VersionType'){
    $fontname = 'Version Type';
  } else if ($fontname == 'Vincent'){
    $fontname = 'Vincent';
  } 

  return $fontname;

}

 ?>