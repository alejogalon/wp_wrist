<?php 

function change_font_to_label($fontname) {

  if($fontname == 'Asset'){
    $fontname = 'kram';
  } else if (){

  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){

  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } else if (){
    
  } 

  return $fontname;

}

 ?>