<?php 

function change_font_to_label($fontname) {

  if($fontname == 'Asset'){
    $fontname = 'hello';
  } else if ($fontname == 'hotel-open'){
    $fontname = 'Hotel Open';
  } else if ($fontname == 'salsbury'){
    $fontname = 'Salsbury';
  } else if ($fontname == 'lourdes'){
    $fontname = 'Lourdes';
  } else if ($fontname == 'museo-slab'){
    $fontname = 'Museo Slab';
  } else if ($fontname == 'great-primer-sc'){
    $fontname = 'Great Primer Sc';    
  } else if ($fontname == 'badaboom-pro'){
    $fontname = 'Bada Boom Pro';
  } else if ($fontname == 'dry-cowboy'){
    $fontname = 'Dry Cowboys';
  } else if ($fontname == 'zubilo-web-black'){
    $fontname = 'Zubilo Web Black';
  } else if ($fontname == 'stencil-std'){
    $fontname = 'Stencil Std';
  } else if ($fontname == 'hobo-std'){
    $fontname = 'Hobo Std';
  } else if ($fontname == 'sneakers-script-narrow'){
    $fontname = 'Sneakers Script Narrow';
  } else if ($fontname == 'hwt-geometric-condensed'){
    $fontname = 'HWT Geometric';
  } else if ($fontname == 'blenny'){
    $fontname = 'Blennys';
  } else if ($fontname == 'balloon-urw-drop-shadow'){
    $fontname = 'Balloon Shadow';
  } else if ($fontname == 'discourse-middle-shadow'){
    $fontname = 'Discourse Shadow';
  } else if ($fontname == 'kinescope'){
    $fontname = 'Kinescope';
  } else if ($fontname == 'le-monde-livre-classic-std-s'){
    $fontname = 'Le Monde Livre';
  } else if ($fontname == 'sanvito-pro'){
    $fontname = 'Sanvito';
  } else if ($fontname == 'jaf-herb'){
    $fontname = 'Jaf Herb';
  } else if ($fontname == 'cabazon'){
    $fontname = 'Cabazon';
  } else if ($fontname == 'ff-market-web'){
    $fontname = 'FF Market Web';
  } else if ($fontname == 'uppercut-angle'){
    $fontname = 'Uppercut Angle';
  } else if ($fontname == 'sketchnote-text'){
    $fontname = 'Sketch Note';
  } else if ($fontname == 'subway-berlin-sc'){
    $fontname = 'Subway Berlin';
  } else if ($fontname == 'lint-mccree'){
    $fontname = 'Lint';
  } else if ($fontname == 'discourse-narrow-outline'){
    $fontname = 'Discourse Narrow';
  } else if ($fontname == 'hwt-van-lanen'){
    $fontname = 'Van Lanen';
  } else if ($fontname == 'aw-conqueror-carved-two'){
    $fontname = 'Conqueror Carved';
  } else if ($fontname == 'strumpf-std-open'){
    $fontname = 'Strumpf';
  } else if ($fontname == 'bigfish'){
    $fontname = 'Bigfish';
  } else if ($fontname == 'adelle'){
    $fontname = 'Adelle';
  } else if ($fontname == 'Alba'){
    $fontname = 'Alba';
  } else if ($fontname == 'Badoom'){
    $fontname = 'Badoom';
  } else if ($fontname == 'Allstar Regular'){
    $fontname = 'Allstar Regular';
  } else if ($fontname == 'Albert'){
    $fontname = 'Albert';
  } else if ($fontname == 'Baron'){
    $fontname = 'Baron';
  } else if ($fontname == 'Beckasin'){
    $fontname = 'Beckasin';
  } else if ($fontname == 'Baveuse'){
    $fontname = 'Baveuse';
  } else if ($fontname == 'Bigmouth'){
    $fontname = 'Bigmouth';
  } else if ($fontname == 'Block Head'){
    $fontname = 'Block Head';
  } else if ($fontname == 'Block Head Fat'){
    $fontname = 'Block Head Fat';
  } else if ($fontname == 'Bob'){
    $fontname = 'Bob';
  } else if ($fontname == 'Bank Gothic'){
    $fontname = 'Bank Gothic';
  } else if ($fontname == 'Bohema'){
    $fontname = 'Bohema';
  } else if ($fontname == 'Calendas Plus'){
    $fontname = 'Calendas Plus';    
  } else if ($fontname == 'Century Gothic'){
    $fontname = 'Century Gothic';
  } else if ($fontname == 'Blockhead Bold'){
    $fontname = 'Blockhead Bold';
  } else if ($fontname == 'Chunk Five'){
    $fontname = 'Chunk Five';
  } else if ($fontname == 'Code Pro'){
    $fontname = 'Code Pro';
  } else if ($fontname == 'Construth'){
    $fontname = 'Construth';
  } else if ($fontname == 'East Lift'){
    $fontname = 'East Lift';
  } else if ($fontname == 'Cop Goth'){
    $fontname = 'Cop Goth';
  } else if ($fontname == 'Courier New'){
    $fontname = 'Courier New';
  } else if ($fontname == 'Cylburn'){
    $fontname = 'Cylburn';
  } else if ($fontname == 'Dense'){
    $fontname = 'Dense';
  } else if ($fontname == 'Dooodleista'){
    $fontname = 'Dooodleista';
  } else if ($fontname == 'Gamma Ray'){
    $fontname = 'Gamma Ray';
  } else if ($fontname == 'Eurosti'){
    $fontname = 'Eurosti';
  } else if ($fontname == 'Fire Starter'){
    $fontname = 'Fire Starter';
  } else if ($fontname == 'Flex'){
    $fontname = 'Flex';
  } else if ($fontname == 'Geared Slab'){
    $fontname = 'Geared Slab';
  } else if ($fontname == 'Geogram'){
    $fontname = 'Geogram';
  } else if ($fontname == 'Good Dog'){
    $fontname = 'Good Dog';
  } else if ($fontname == 'Grand Hotel'){
    $fontname = 'Grand Hotel';
  } else if ($fontname == 'Habana'){
    $fontname = 'Habana';
  } else if ($fontname == 'Haymaker'){
    $fontname = 'Haymeker';
  } else if ($fontname == 'Higher'){
    $fontname = 'Higher';
  } else if ($fontname == 'Hiruko Black'){
    $fontname = 'Hiruko Black';
  } else if ($fontname == 'Atama Geomarice'){
    $fontname = 'Atama Geomarice';
  } else if ($fontname == 'Kilogram'){
    $fontname = 'Kilogram';
  } else if ($fontname == 'Lead Ville Inline'){
    $fontname = 'Lead Ville Inline';
  } else if ($fontname == 'Keep on Truckin'){
    $fontname = 'Keep on Truckin';
  } else if ($fontname == 'Klinic Slab'){
    $fontname = 'Klinic Slab';
  } else if ($fontname == 'Komoda'){
    $fontname = 'Komoda';
  } else if ($fontname == 'Lavanderia'){
    $fontname = 'Lavanderia';
  } else if ($fontname == 'Linny'){
    $fontname = 'Linny';
  } else if ($fontname == 'Lobster'){
    $fontname = 'Lobster';
  } else if ($fontname == 'Lucida Sans'){
    $fontname = 'Lucida Sans';
  } else if ($fontname == 'Lucida Console'){
    $fontname = 'Lucida Console';
  } else if ($fontname == 'Makhina'){
    $fontname = 'Makhina';
  } else if ($fontname == 'Master Force'){
    $fontname = 'Master Force';
  } else if ($fontname == 'Metropolis'){
    $fontname = 'Metropolis';
  } else if ($fontname == 'Lead Ville System'){
    $fontname = 'Lead Ville System';
  } else if ($fontname == 'Molesk'){
    $fontname = 'Molesk';
  } else if ($fontname == 'Moonshiner'){
    $fontname = 'Moonshiner';
  } else if ($fontname == 'Nexa Light'){
    $fontname = 'Nexa Light';
  } else if ($fontname == 'Nexa Bold'){
    $fontname = 'Nexa Bold';
  } else if ($fontname == 'Old English'){
    $fontname = 'Old English';
  } else if ($fontname == 'Nova Mono'){
    $fontname = 'Nova Mono';
  } else if ($fontname == 'Nymphs Handwriting'){
    $fontname = 'Nymphs Handwriting';
  } else if ($fontname == 'Ostrich Sans'){
    $fontname = 'Ostrich Sans';
  } else if ($fontname == 'Parisish'){
    $fontname = 'Parisish';
  } else if ($fontname == 'Quadranta'){
    $fontname = 'Quadranta';
  } else if ($fontname == 'Planet Benson 2'){
    $fontname = 'Planet Benson 2';
  } else if ($fontname == 'Quadranta Bold'){
    $fontname = 'Quadranta Bold';
  } else if ($fontname == 'Quadranta Regular'){
    $fontname = 'Quadranta Regular';
  } else if ($fontname == 'Roddenberry'){
    $fontname = 'Roddenberry';
  } else if ($fontname == 'Reckoner'){
    $fontname = 'Reckoner';
  } else if ($fontname == 'Robo Fan Free'){
    $fontname = 'Robo Fan Free';
  } else if ($fontname == 'Stonehenge'){
    $fontname = 'Stonehenge';
  } else if ($fontname == 'Seven Swordsmen'){
    $fontname = 'Seven Swordsmen';
  } else if ($fontname == 'Slapstick Comic'){
    $fontname = 'Slapstick Comic';
  } else if ($fontname == 'Unlike Edge'){
    $fontname = 'Unlike Edge';
  } else if ($fontname == 'Supermarket Sale Display'){
    $fontname = 'Supermarket Sale Display';
  }else if ($fontname == 'Supermarket Sale Regular'){
    $fontname = 'Supermarket Sale Regular';
  } else if ($fontname == 'The Bubble'){
    $fontname = 'The Bubble';
  } else if ($fontname == 'Track Type'){
    $fontname = 'Track Type';
  } else if ($fontname == 'True Love'){
    $fontname = 'True Love';
  } else if ($fontname == 'Wood Shop'){
    $fontname = 'Wood Shop';
  } else if ($fontname == 'Wood Warrior'){
    $fontname = 'Wood Warrior';
  } else if ($fontname == 'Version Type'){
    $fontname = 'Version Type';
  } else if ($fontname == 'Vincent'){
    $fontname = 'Vincent';
  } 

  return $fontname;

}

 ?>
