<?php

//Template Name: WC Logos Layout

get_header();


get_footer();