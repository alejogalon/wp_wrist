<?php

//Template Name: WC Prices Layout

get_header();

echo '<pre>';
print_r($GLOBALS['wbc_settings']->products);
echo '</pre>';



get_footer();