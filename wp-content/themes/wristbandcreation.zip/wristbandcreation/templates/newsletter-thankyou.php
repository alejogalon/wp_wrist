<?php 
 /*
	Template Name: Newsletter Thank You
 */

get_header();
?>
<span class="entry-title">
	Thank You!
</span>
	<div class="container">
		<div class="section-content text-center">
			<p>Your sign-up request was successful! Please check your email inbox to confirm.</p>
		</div>
	</div>
<?php get_footer(); ?>