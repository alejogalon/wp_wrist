
<div class="col-md-10 white">
	<div class="gap-top"></div>
	<div class="dash-title-holder">
		<h2>Notifications<?php echo $order_id; ?></h2>
	</div>
	<hr class="divider-full" />
	<div class="dash-filter">
		<!-- <span>Filter:</span> -->
	</div>
	<div style="height: 10px"></div>
	<div class="notif-container">
		<ul>
			<li>
				<a href="#">
					<div class="single-notif shadow-wrap">
						<h3>Title of the Report <span class="time-ago">1 hour ago</span></h3>
						<span>Last Reply by Admin -</span>
						<span>Lorem ipsum dolor sit amet, his no alii vidit. Ei eirmod viderer equidem pro, eum fugit verear ex. Est ea dico aliquam scribentur. Pertinax necessitatibus ne ius, ea meliore nonumes per. Nec brute mollis id.</span>
					</div>
				</a>
			</li>
		</ul>
	</div>
</div>

