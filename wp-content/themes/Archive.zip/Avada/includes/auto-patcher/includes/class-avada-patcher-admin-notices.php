<?php

class Avada_Patcher_Admin_Notices {

}
